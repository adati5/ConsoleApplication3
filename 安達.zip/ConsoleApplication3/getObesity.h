#include<string>
string getObesity(double bmi);
